class DashboardController < ApplicationController
  def index
    @task_type = TaskType.all
    @tasks = Task.all
    @tasks = Task.includes(:comments).all
    @tasks = Task.includes(:task_type).all
  end
end
