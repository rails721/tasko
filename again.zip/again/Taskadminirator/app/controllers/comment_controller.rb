class CommentsController < ApplicationController
  before_action :set_task
  before_action :set_comment, only: [ :edit, :update, :destroy ]

  rescue_from ActiveRecord::RecordNotFound, with: :comment_not_found

  def edit
  end

  def update
  end


  private

  def set_task
    @task = Task.find(params[:task_id])
  end

  def set_comment
    @comment = @task.comments.find(params[:id])
  end

  def comment_not_found
    flash[:alert] = "Comment not found."
    redirect_to task_path(@task)
  end
end
