class Task < ApplicationRecord
  belongs_to :user
  belongs_to :task_type

  validates :task_name, presence: true
  validates :status, presence: true
  validates :task_type, presence: true
  validates :user, presence: true
  has_many :comments, dependent: :destroy
  accepts_nested_attributes_for :comments, allow_destroy: true
  validates :task_type_id, presence: true
  belongs_to :creator, class_name: "User", foreign_key: "created_by"
end
